var xcoords = [],
	ycoords = [];
	xamountcoords = [635, 760, 885, 1010, 760, 885, 1010, 760, 885, 1010];
	yamountcoords = [345, 220, 220, 220, 345, 345, 345, 470, 470, 470];
	directions = ["left", "back", "right", "front"],
	movement = [-1, -20, 1, 20],
	pos = 0,
	direction = "front",
	inventoryOpen = 0;

document.addEventListener("keydown", keyDownTextField, false);

function keyDownTextField(e) {
var keyCode = e.keyCode;
	if(inventoryOpen==0){
	    if(keyCode==37) {
	        Turn(0);
	    }else if(keyCode==38) {
	        Turn(1);
	    }else if(keyCode==39) {
	        Turn(2);
	    }else if(keyCode==40) {
	        Turn(3);
	    }else if(keyCode==65) {
	        Move(0);
	    }else if(keyCode==87) {
	        Move(1);
	    }else if(keyCode==68) {
	        Move(2);
	    }else if(keyCode==83) {
	        Move(3);
	    }else if(keyCode==32) {
	    	Action();
	    }
	}
	if(keyCode==69) {
    	Inventory();
	}
}

for(i=0; i<20; i++){
	xcoords.push(i*64);
}

for(i=0; i<10; i++){
	ycoords.push(i*62);
}

for(j=0; j<10; j++){
	for(i=0; i<20; i++){
		var k = j * 20;
		eval("var field" + (i+k) + " = TypeSelector('field" + (i+k) + "');");
		eval("var image" + (i+k) + " = document.createElement('img');");
		eval("image" + (i+k) + ".setAttribute('id', 'image" + (i+k) + "');");
		eval("document.getElementById('imagefield').appendChild(image" + (i+k) +");");
		eval("document.getElementById('image" + (i+k) + "').src = ImageSelector(field" + (i+k) + ");");
		eval("image" + (i+k) + " = document.querySelector('#image" + (i+k) + "');");
		eval("document.getElementById('image" + (i+k) + "').style.position = 'fixed';");
		eval("document.getElementById('image" + (i+k) + "').style.top = '" + ycoords[j] + "px';");
		eval("document.getElementById('image" + (i+k) + "').style.left = '" + xcoords[i] + "px';");
	}
}

for(i=0; i<10; i++){
	eval("document.getElementById('amount" + i + "').style.left = '" + xamountcoords[i] + "px';");
	eval("document.getElementById('amount" + i + "').style.top = '" + yamountcoords[i] + "px';");
}

UpdatePlayer();

function TypeSelector(field){
	if(field == 'field0'){
		return "grass";
	}
	var random = Math.random();
	if(random <= 0.02){
		return "rock";
	}else if(random <= 0.04){
		return "tree";
	}else if(random <= 0.06){
		return "bush";
	}else{
		return "grass";
	}
}

function ImageSelector(field){
	var image = eval(field + ".image");
	return image;
}

function UpdateImage(image, replacement){
	document.getElementById(image).src = replacement;
}

function UpdatePlayer(){
	eval("var current = 'image" + pos + "'");
	UpdateImage(current, eval("player." + direction + ".image"));
}

function Turn(turn){
	direction = directions[turn];
	UpdatePlayer();
}

function Move(move){
	Turn(move);
	if(!((pos <= 19 && move == 1) || (pos >= 180 && move == 3) || (pos % 20 == 19 && move == 2) || (pos % 20 == 0 && move == 0))){
		if(eval(eval("field" + (pos + movement[move])) + ".solid == 'N'")){
			pos += movement[move];
			UpdatePlayer();
			eval("UpdateImage('image" + (pos - movement[move]) + "', eval(eval('field' + (pos - movement[move])) + '.image'))");
		}
	}
}

function Inventory(){
	if(inventoryOpen == 0){
		inventoryOpen = 1;
		document.getElementById("inventory").style.visibility = "visible";
	}else if(inventoryOpen == 1){
		inventoryOpen = 0;
		document.getElementById("inventory").style.visibility = "hidden";
	}
}

function Action(){
	if(ActionChecker() == true){
		if(eval(eval("field" + (pos + (movement[(directions.indexOf(direction))]))) + '.action') == 'item'){
			UpdateInventory((eval(eval("field" + (pos + (movement[(directions.indexOf(direction))]))) + '.item')), (eval(eval("field" + (pos + (movement[(directions.indexOf(direction))]))) + '.amount')));
		}
	}
}

function ActionChecker(){
	if(!((pos <= 19 && direction == "back") || (pos >= 180 && direction == "front") || (pos % 20 == 19 && direction == "right") || (pos % 20 == 0 && direction == "left"))){
		return true;
	}else{
		return false;
	}
}

function UpdateInventory(item, amount){
	for(i=1; i<10; i++){
		if(i == 10){break;}
		if(eval("inventory.slot" + i + ".item") == item && eval("inventory.slot" + i + ".amount") < eval(eval("inventory.slot" + i + ".item") + ".max")){
			eval("inventory.slot" + i + ".amount += amount");
			if(eval("inventory.slot" + i + ".amount") > eval(eval("inventory.slot" + i + ".item") + ".max")){
				var residue = eval("inventory.slot" + i + ".amount - " + eval(eval("inventory.slot" + i + ".item") + ".max"));
				eval("inventory.slot" + i + ".amount = " + eval(eval("inventory.slot" + i + ".item") + ".max"));
				RenderInventory(i);
				UpdateInventory(eval("inventory.slot" + i + ".item"), residue);
			}
			RenderInventory(i);
			break;
		}else if(eval("inventory.slot" + i + ".item") == "N"){
			eval("inventory.slot" + i + ".item = item");
			eval("inventory.slot" + i + ".amount = amount");
			RenderInventory(i);
			break;
		}
	}
}

function RenderInventory(slot){
	if(eval("inventory.slot" + slot + ".item") == "N"){
		eval("document.getElementById('slot" + slot + "image').src = ''");
		eval("document.getElementById('amount" + slot + "').innerHTML = ''");
	}else{
		eval("document.getElementById('slot" + slot + "image').src = eval(inventory.slot" + slot + ".item + '.image')");
		eval("document.getElementById('amount" + slot + "').innerHTML = eval(inventory.slot" + slot + ".amount)");
	}
}

function Slot(slot){
	if(slot != 0){
		if(eval("inventory.slot" + slot + ".item") == inventory.slot0.item){
			inventory.slot0.amount += eval("inventory.slot" + slot + ".amount");
			if(inventory.slot0.amount > eval(inventory.slot0.item + ".max")){
				residue = inventory.slot0.amount - eval(eval("inventory.slot0.item") + ".max");
				inventory.slot0.amount = eval(inventory.slot0.item + ".max");
				eval("inventory.slot" + slot + ".amount = residue");
			}else{
				eval("inventory.slot" + slot + ".amount = 0");
				eval("inventory.slot" + slot + ".item = 'N'");
			}
			RenderInventory(slot);
			RenderInventory(0);
		}else if(eval("inventory.slot" + slot + ".item") != "N"){
			var tempitem = inventory.slot0.item;
			var tempamount = inventory.slot0.amount;
			inventory.slot0.item = eval("inventory.slot" + slot + ".item");
			inventory.slot0.amount = eval("inventory.slot" + slot + ".amount");
			eval("inventory.slot" + slot + ".item = tempitem");
			eval("inventory.slot" + slot + ".amount = tempamount");
			RenderInventory(0);
			RenderInventory(slot);
		}
	}else{
		if(inventory.slot0.item != "N"){
			for(i=1; i<10; i++){
				if(i == 10){break;}
				var filled = eval("inventory.slot" + i + ".item").toString();
				filledamount = eval("inventory.slot" + i + ".amount");
				var filledmax = eval(eval("inventory.slot" + i + ".item") + ".max");
				if(filled == "N"){
					eval("inventory.slot" + i + ".item = inventory.slot0.item");
					eval("inventory.slot" + i + ".amount = inventory.slot0.amount");
					inventory.slot0.item = "N";
					inventory.slot0.amount = 0;
					RenderInventory(i);
					RenderInventory(0);
					break;
				}else if(filled == inventory.slot0.item && filledamount < filledmax){
					eval("inventory.slot" + i + ".amount += inventory.slot0.amount");
					if(eval("inventory.slot" + i + ".amount") > filledmax){
						residue = eval("inventory.slot" + i + ".amount") - filledmax;
						eval("inventory.slot" + i + ".amount = filledmax");
						inventory.slot0.amount = residue;
						RenderInventory(i);
						RenderInventory(0);
						console.log(i);
						if(inventory.slot0.amount == 0){
							break;
						}
					}else{
						inventory.slot0.item = "N";
						inventory.slot0.amount = 0;
						RenderInventory(i);
						RenderInventory(0);
						break;
					}
				}
			}
		}
	}
}