var grass = {
		image: "Images/Grass.png",
		solid: "N",
		action: "N",
		item: "N"
	},
	rock = {
		image: "Images/Rock.png",
		solid: "Y",
		action: "item",
		require: "pickaxe",
		item: "stone",
		amount: 1
	},
	bush = {
		image: "Images/BerryBush.png",
		solid: "Y",
		action: "item",
		require: "N",
		item: "berry",
		amount: 5
	},
	tree = {
		image: "Images/Tree.png",
		solid: "Y",
		action: "item",
		require: "axe",
		item: "wood",
		amount: 5
	},
	player = {
		left: {
			image: "Images/Player/Left.png"
		},
		front: {
			image: "Images/Player/Front.png"
		},
		right: {
			image: "Images/Player/Right.png"
		},
		back: {
			image: "Images/Player/Back.png"
		}
	},
	inventory = {
		slot1: {
			item: "N",
			amount: 0
		},
		slot2: {
			item: "N",
			amount: 0
		},
		slot3: {
			item: "N",
			amount: 0
		},
		slot4: {
			item: "N",
			amount: 0
		},
		slot5: {
			item: "N",
			amount: 0
		},
		slot6: {
			item: "N",
			amount: 0
		},
		slot7: {
			item: "N",
			amount: 0
		},
		slot8: {
			item: "N",
			amount: 0
		},
		slot9: {
			item: "N",
			amount: 0
		},
		slot0: {
			item: "N",
			amount: 0
		}

	},
	berry = {
		image: "Images/Items/Berry.png",
		use: "food",
		impact: 5,
		max: 50
	},
	wood = {
		image: "Images/Items/Wood.png",
		use: "N",
		max: 50
	},
	stone = {
		image: "Images/Items/Stone.png",
		use: "N",
		max: 50
	}