/*

  DATA MEANING:

  ITEMS:
  TYPE = TYPE/NAME OF ITEM
  USE = THE ITEM'S USE
  AMOUNT (ITEMS) = HOW MANY OF THE ITEM WILL BE RECEIVED UPON CRAFTING
  EFFECT = THE EFFECT IT HAS WHEN YOU USE IT
  MAX = THE MAX AMOUNT OF THIS ITEM IN A SLOT
  CURRENT = HOW MUCH THE PLAYER CURRENTLY HAS
  RECIPE = THE RECIPE ON HOW TO CRAFT THIS ITEM

  TILES:
  TYPE = TYPE/NAME OF THE TILE
  SOLID = IF THE TILE IS ABLE TO BE WALKED THROUGH
  ACTION = WHAT HAPPENS WHEN SPACE IS PRESSED WHILE LOOKING AT THIS TILE
  REQUIRE = WHICH TOOL IS REQUIRED TO HARVEST FROM THIS TILE
  ITEM = WHICH ITEM IS HARVESTED FROM THIS TILE
  AMOUNT (TILES) = HOW MANY ITEMS WILL BE GATHERED FROM THIS TILE
  TOTAL = AMOUNT OF ITEMS HARVESTABLE FROM THIS TILE
  GATHERED = AMOUNT OF ITEMS HARVESTED FROM THIS TILE
  
*/

empty = {
    type: "N",
    use: "N",
    effect: 0,
    max: 0,
    current: 0
  }

var recipes = {
	workbench: [
		"wood", 7
  ],
  chest: [
    "wood", 10
  ],
  axe: [
    "wood", 4
  ],
  firepit: [
    "wood", 2
  ],
  pickaxe: [
    "wood", 4
  ],
  firestarter: [
    "wood", 3,
    "stone", 2,
    "rope", 1
  ],
  rope: [
    "grass", 3
  ],
  knife: [
    "wood", 2,
    "stone", 2
  ],
  bowl: [
    "wood", 3,
  ]
}

var berry = {
		type: "berry",
		use: "food",
		effect: 5,
		max: 50,
		current: 0
	},
	wood = {
		type: "wood",
		use: "N",
		effect: 0,
		max: 50,
		current: 0
	},
	stone = {
		type: "stone",
		use: "N",
		effect: 0,
		max: 50,
		current: 0
	},
  grass = {
    type: "grass",
    use: "N",
    effect: 0,
    max: 50,
    current: 0
  },
	grasstile = {
		type: "grasstile",
		solid: "N",
		action: "N",
    require: "N",
		item: "N",
    amount: 0,
    total: 0,
    gathered: 0
	},
	rock = {
		type: "rock",
		solid: "Y",
		action: "item",
		require: "pickaxe",
		item: stone,
		amount: 1,
		total: 100,
		gathered: 0
	},
	berrybush = {
		type: "berrybush",
		solid: "Y",
		action: "item",
		require: "N",
		item: berry,
		amount: 5,
		total: 10,
		gathered: 0
	},
	bush = {
		type: "bush",
		solid: "Y",
		action: "N",
		require: "N",
		item: "N",
		amount: 0,
		total: 0,
		gathered: 0
	},
	tree = {
		type: "tree",
		solid: "Y",
		action: "item",
		require: "axe",
		item: wood,
		amount: 5,
		total: 20,
		gathered: 0,
	},
  workbenchtile = {
    type: "workbenchtile",
    solid: "Y",
    action: "craft",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0
  },
  workbench = {
    type: "workbench",
    use: "place",
    amount: 1,
    effect: workbenchtile,
    max: 1,
    current: 0,
    recipe: recipes.workbench
  },
  chesttile = {
    type: "chesttile",
    solid: "Y",
    action: "chest",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0,
    ypos: 0,
    xpos: 0
  },
  chest = {
    type: "chest",
    use: "place",
    amount: 1,
    effect: chesttile,
    max: 1,
    current: 0,
    recipe: recipes.chest
  },
  axe = {
    type: "axe",
    use: "chop",
    amount: 1,
    effect: 0,
    max: 1,
    current: 0,
    recipe: recipes.axe
  },
  pickaxe = {
    type: "pickaxe",
    use: "N",
    amount: 1,
    effect: 0,
    max: 1,
    current: 0,
    recipe: recipes.pickaxe
  },
  ash = {
    type: "ash",
    use: "N",
    amount: 1,
    effect: 0,
    max: 50,
    current: 0
  },
  firepittile = {
    type: "firepittile",
    solid: "Y",
    action: "N",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0
  },
  firepittileon = {
    type: "firepittileon",
    solid: "Y",
    action: "cook",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0
  },
  firepittileburned = {
    type: "firepittileburned",
    solid: "Y",
    action: "item",
    require: "N",
    item: ash,
    amount: 1,
    total: 1,
    gathered: 0
  },
  firepit = {
    type: "firepit",
    use: "place",
    amount: 1,
    effect: firepittile,
    max: 1,
    current: 0,
    recipe: recipes.firepit
  },
  water = {
    type: "water",
    solid: "Y",
    action: "N",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0
  },
  firestarter = {
    type: "firestarter",
    use: "fire",
    amount: 1,
    effect: 0,
    max: 1,
    current: 0,
    recipe: recipes.firestarter
  },
  rope = {
    type: "rope",
    use: "N",
    amount: 1,
    effect: 0,
    max: 25,
    current: 0,
    recipe: recipes.rope
  },
  growngrass = {
    type: "growngrass",
    solid: "Y",
    action: "item",
    require: "knife",
    item: grass,
    amount: 1,
    total: 1,
    gathered: 0
  },
  wateredgrass = {
    type: "wateredgrass",
    solid: "Y",
    action: "N",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0,
    grow: 0,
    stage: growngrass
  },
  knife = {
    type: "knife",
    use: "harvest",
    amount: 1,
    effect: 0,
    max: 1,
    current: 0,
    recipe: recipes.knife
  },
  bowlfull = {
    type: "bowlfull",
    use: "water",
    amount: 1,
    effect: 0,
    max: 1,
    current: 0
  },
  bowl = {
    type: "bowl",
    use: "fill",
    amount: 1,
    effect: bowlfull,
    max: 1,
    current: 0,
    recipe: recipes.bowl
  },
  emptytree = {
    type: "emptytree",
    solid: "Y",
    action: "N",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0
  },
  treesprouttile = {
    type: "treesprouttile",
    solid: "Y",
    action: "N",
    require: "N",
    item: "N",
    amount: 0,
    total: 0,
    gathered: 0,
    grow: 0,
    stage: emptytree
  },
  treesprout = {
    type: "treesprout",
    use: "place",
    amount: 1,
    effect: treesprouttile,
    max: 1,
    current: 0
  }

var craftinglist = [
  workbench,
  chest,
  axe,
  firepit,
  pickaxe,
  knife,
  rope,
  firestarter,
  bowl
]