/* global grass, rock, tree, berrybush, bush, empty */
/* exported Slot, Remove */
var xcoords = []
var ycoords = []
var xamountcoords = [635, 760, 885, 1010, 760, 885, 1010, 760, 885, 1010]
var yamountcoords = [345, 220, 220, 220, 345, 345, 345, 470, 470, 470]
var xchestamountcoords = [205, 330, 455, 205, 330, 455, 205, 330, 455]
var ychestamountcoords = [220, 220, 220, 345, 345, 345, 470, 470, 470]
var directions = ['left', 'back', 'right', 'front']
var horizontalmovement = [-1, 0, 1, 0]
var verticalmovement = [0, -1, 0, 1]
var pos = [0, 0]
var direction = 'front'
var inventoryOpen = 0
var chestopen = 0
var inventory = []
var remove = 0
var i = 0
var addsub = 'add'
var oldsidescreen = ''
var craftingarray = [craftinglist[0], craftinglist[1], craftinglist[2]]
var craftingscroll = 0
var chosencraft = Object.create(empty)

inventory[0] = axe
inventory[0].current = 1
RenderInventory(0)
for (i = 1; i < 10; i++) {
  inventory[i] = Object.create(empty)
}

document.addEventListener('keydown', keyDownTextField, false)

function keyDownTextField (e) {
  var keyCode = e.keyCode
  if (inventoryOpen === 0) {
    if (keyCode === 37) {
      Turn(0)
    } else if (keyCode === 38) {
      Turn(1)
    } else if (keyCode === 39) {
      Turn(2)
    } else if (keyCode === 40) {
      Turn(3)
    } else if (keyCode === 65) {
      Move(0)
    } else if (keyCode === 87) {
      Move(1)
    } else if (keyCode === 68) {
      Move(2)
    } else if (keyCode === 83) {
      Move(3)
    } else if (keyCode === 32) {
      Action()
    } else if (keyCode === 70) {
      Use()
  	}
  }else if(inventoryOpen === 1 && oldsidescreen === 'crafting'){
    if (keyCode === 38 || keyCode === 87) {
      Scroll(-1)
    } else if (keyCode === 40 || keyCode === 83) {
      Scroll(1)
    }
  }

  if (keyCode === 69) {
    Inventory('stats')
  }
}

for (i = 0; i < 20; i++) {
  xcoords.push(i * 64)
}

for (i = 0; i < 10; i++) {
  ycoords.push(i * 62)
}

var field = []
for (var vertical = 0; vertical < 10; vertical++) {
  field[vertical] = []
  for (var horizontal = 0; horizontal < 20; horizontal++) {
    field[vertical][horizontal] = Object.create(TypeSelector())
    if (vertical === 0 && horizontal === 0) {
      field[vertical][horizontal] = grasstile
    }
    var newTile = document.createElement('span')
    newTile.setAttribute('id', 'image_' + vertical + '_' + horizontal)
    newTile.setAttribute('class', 'tile ' + field[vertical][horizontal].type)
    newTile.setAttribute('data-vertical', vertical)
    newTile.setAttribute('data-horizontal', horizontal)
    document.getElementById('imagefield').appendChild(newTile)
  }
}

for (i = 0; i < 10; i++) {
  document.getElementById('amount' + i).style.left = xamountcoords[i] + 'px'
  document.getElementById('amount' + i).style.top = yamountcoords[i] + 'px'
}

for (i = 0; i < 9; i++) {
  document.getElementById('chestamount' + i).style.left = xchestamountcoords[i] + 'px'
  document.getElementById('chestamount' + i).style.top = ychestamountcoords[i] + 'px'
}

var storage = []
for(i = 0; i < 10; i++){
  storage[i] = []
  for(j = 0; j < 20; j++){
    storage[i][j] = []
    for(k = 0; k < 9; k++){
      storage[i][j][k] = Object.create(empty)
    }
  }
}

UpdatePlayer()

function TypeSelector () {
  var random = Math.random()
  if (random <= 0.02) {
    return rock
  } else if (random <= 0.04) {
    return tree
  } else if (random <= 0.06) {
    return berrybush
  } else if (random <= 0.07) {
    return water
  } else {
    return grasstile
  }
}

function UpdateImage (image, replacement) {
  document.getElementById(image).setAttribute('class', 'tile ' + replacement)
}

function UpdatePlayer () {
  var current = 'image_' + pos[0] + '_' + pos[1]
  UpdateImage(current, direction)
}

function Turn (turn) {
  direction = directions[turn]
  UpdatePlayer()
}

function Move (move) {
  Turn(move)
  // 0 = left
  // 1 = up
  // 2 = right
  // 3 = down

  if (!((pos[0] === 0 && move === 1) || (pos[0] === 9 && move === 3) || (pos[1] === 0 && move === 0) || (pos[1] === 19 && move === 2))) {
    if (field[pos[0] + verticalmovement[move]][pos[1] + horizontalmovement[move]].solid === 'N') {
      var oldpos = pos
      pos[0] += verticalmovement[move]
      pos[1] += horizontalmovement[move]
      UpdatePlayer()
      var oldfield = 'image_' + (pos[0] - verticalmovement[move]) + '_' + (pos[1] - horizontalmovement[move])
      UpdateImage(oldfield, field[oldpos[0]][oldpos[1]].type)
    }
  }
}

function Inventory (sidescreen) {
  if (inventoryOpen === 0) {
    var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
    var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
    inventoryOpen = 1
    document.getElementById(sidescreen).style.visibility = 'visible'
    document.getElementById('inventory').style.visibility = 'visible'
    oldsidescreen = sidescreen
    if(sidescreen === 'chest'){
      chestopen = 1
      for(i = 0; i < 9; i++){
        RenderChest(i, newY, newX)
      }
    }
  } else if (inventoryOpen === 1) {
    inventoryOpen = 0
    document.getElementById(oldsidescreen).style.visibility = 'hidden'
    document.getElementById('inventory').style.visibility = 'hidden'
    if(oldsidescreen === 'crafting'){
      document.getElementById('recipetext').innerHTML = ''
      chosencraft = Object.create(empty)
    }else if(oldsidescreen === 'chest'){
      chestopen = 0
    }
  }
}

function Action () {
  if (ActionChecker() === true) {
    var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
    var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
    var targetField = field[newY][newX]
    if (targetField.action === 'item') {
      if(targetField.require === inventory[0].type && inventory[0].type !== 'N'){
        var amount = CheckGatherAmount(newY, newX)
        var invcheck = UpdateInventory(targetField.item, amount)
        if(invcheck === true){
          field[newY][newX].gathered += amount
        }
      }else if(targetField.require === 'N'){
        var amount = CheckGatherAmount(newY, newX)
        var invcheck = UpdateInventory(targetField.item, amount)
        if(invcheck === true){
          field[newY][newX].gathered += amount
        }
      }
    }else if(targetField.action === 'craft'){
      Inventory('crafting')
    }else if(targetField.action === 'chest'){
      Inventory('chest')
    }
  }
}

function ActionChecker () {
  if (!((pos[0] <= 0 && direction === 'back') || (pos[0] >= 9 && direction === 'front') || (pos[1] >= 19 && direction === 'right') || (pos[1] <= 0 && direction === 'left'))) {
    return true
  } else {
    return false
  }
}

function UpdateInventory (item, amount) {
  for (i = 1; i < 10; i++) {
    if (i === 10) {
      break
    }
    if (inventory[i].type === item.type && inventory[i].current < inventory[i].max) {
      inventory[i].current += amount
      if (inventory[i].current > inventory[i].max) {
        var residue = inventory[i].current - inventory[i].max
        inventory[i].current = inventory[i].max
        RenderInventory(i)
        UpdateInventory(inventory[i], residue)
      }
      RenderInventory(i)
      return true
      break
    } else if (inventory[i].type === 'N') {
      inventory[i] = Object.create(item)
      inventory[i].current = amount
      RenderInventory(i)
      return true
      break
    }
  }
}

function UpdateChest (item, amount) {
  var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
  var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
  for (i = 0; i < 9; i++) {
    if (i === 9) {
      break
    }
    if (storage[newY][newX][i].type === item.type && storage[newY][newX][i].current < storage[newY][newX][i].max) {
      storage[newY][newX][i].current += amount
      if (storage[newY][newX][i].current > storage[newY][newX][i].max) {
        var residue = storage[newY][newX][i].current - storage[newY][newX][i].max
        storage[newY][newX][i].current = storage[newY][newX][i].max
        RenderChest(i)
        UpdateChest(storage[newY][newX][i], residue)
      }
      RenderChest(i)
      return true
      break
    } else if (storage[newY][newX][i].type === 'N') {
      storage[newY][newX][i] = Object.create(item)
      storage[newY][newX][i].current = amount
      RenderChest(i)
      return true
      break
    }
  }
}

function RenderInventory (slot) {
  if (inventory[slot].type === 'N') {
    document.getElementById('slot' + slot + 'image').setAttribute('class', 'slot ' + empty.type)
    document.getElementById('amount' + slot).innerHTML = ''
  } else {
    document.getElementById('slot' + slot + 'image').setAttribute('class', 'slot ' + inventory[slot].type)
    document.getElementById('amount' + slot).innerHTML = inventory[slot].current
    if(inventory[slot].max === 1){
      document.getElementById('amount' + slot).innerHTML = ''
    }
  }
}

function RenderChest (slot) {
  var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
  var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
  if (storage[newY][newX][slot].type === 'N') {
    document.getElementById('chestslot' + slot + 'image').setAttribute('class', 'slot ' + empty.type)
    document.getElementById('chestamount' + slot).innerHTML = ''
  } else {
    document.getElementById('chestslot' + slot + 'image').setAttribute('class', 'slot ' + storage[newY][newX][slot].type)
    document.getElementById('chestamount' + slot).innerHTML = storage[newY][newX][slot].current
    if(storage[newY][newX][slot].max === 1){
      document.getElementById('chestamount' + slot).innerHTML = ''
    }
  }
}

function Slot (slot, type) {
  var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
  var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
  if (type === 'add') {
    if (chestopen === 1){
      var checkspace = UpdateChest(inventory[slot], inventory[slot].current)
      if(checkspace === true){
        inventory[slot] = Object.create(empty)
        RenderInventory(slot)
      }
    }else if (slot !== 0) {
      if (inventory[slot].type === inventory[0].type) {
        inventory[0].current += inventory[slot].current
        if (inventory[0].current > inventory[0].max) {
          var residue = inventory[0].current - inventory[0].max
          inventory[0].current = inventory[0].max
          inventory[slot].current = residue
        } else {
          inventory[slot] = Object.create(empty)
        }
        RenderInventory(slot)
        RenderInventory(0)
      } else if (inventory[slot].type !== 'N') {
        var temptype = inventory[0]
        var tempcurrent = inventory[0].current
        inventory[0] = inventory[slot]
        inventory[0].current = inventory[slot].current
        inventory[slot] = temptype
        inventory[slot].current = tempcurrent
        RenderInventory(0)
        RenderInventory(slot)
      }
    } else {
      if (inventory[0].type !== 'N') {
        for (i = 1; i < 10; i++) {
          if (i === 10) {
            break
          }
          var filled = inventory[i].type
          var filledcurrent = inventory[i].current
          var filledmax = inventory[i].max
          if (filled === 'N') {
            inventory[i] = inventory[0]
            inventory[i].current = inventory[0].current
            inventory[0] = empty
            RenderInventory(i)
            RenderInventory(0)
            break
          } else if (filled === inventory[0].type && filledcurrent < filledmax) {
            inventory[i].current += inventory[0].current
            if (inventory[i].current > filledmax) {
              residue = inventory[i].current - filledmax
              inventory[i].current = filledmax
              inventory[0].current = residue
              RenderInventory(i)
              RenderInventory(0)
              if (inventory[0].current === 0) {
                break
              }
            } else {
              inventory[0] = empty
              RenderInventory(i)
              RenderInventory(0)
              break
            }
          }
        }
      }
    }
  } else if (type === 'sub') {
    if (remove === 1) {
      inventory[slot].current -= 1
      if (inventory[slot].current === 0) {
        inventory[slot] = Object.create(empty)
      }
      RenderInventory(slot)
    } else if (remove === 2) {
      inventory[slot] = Object.create(empty)
      RenderInventory(slot)
    }
  }
}

function ChestSlot(slot, type){
  var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
  var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
  if(type === 'add'){
    var checkspace = UpdateInventory(storage[newY][newX][slot], storage[newY][newX][slot].current)
    if(checkspace === true){
      storage[newY][newX][slot] = Object.create(empty)
      RenderChest(slot)
    }
  } else if (type === 'sub') {
    if (remove === 1) {
      storage[newY][newX][slot].current -= 1
      if (storage[newY][newX][slot].current === 0) {
        storage[newY][newX][slot] = Object.create(empty)
      }
      RenderChest(slot)
    } else if (remove === 2) {
      storage[newY][newX][slot] = Object.create(empty)
      RenderChest(slot)
    }
  }
}

function CheckGatherAmount (y, x) {
  if (field[y][x].gathered + field[y][x].amount > field[y][x].total) {
    var returnamount = field[y][x].total - field[y][x].gathered
    DepleteField(y, x)
    return returnamount
  } else if (field[y][x].gathered + field[y][x].amount === field[y][x].total) {
    returnamount = field[y][x].amount
    DepleteField(y, x)
    return returnamount
  } else {
    return field[y][x].amount
  }
}

function DepleteField (y, x) {
  if (field[y][x].type === 'berrybush') {
    field[y][x] = Object.create(bush)
    UpdateImage('image_' + y + '_' + x, field[y][x].type)
    setTimeout(function () { Replete(y, x) }, 180000)
  } else {
    field[y][x] = Object.create(grasstile)
    UpdateImage('image_' + y + '_' + x, field[y][x].type)
  }
}

var secret = document.createElement('script')
secret.setAttribute('src', 'Secret.js')
document.body.appendChild(secret)
function Replete (y, x) {
  if (field[y][x].type === 'bush') {
    field[y][x] = Object.create(berrybush)
    UpdateImage('image_' + y + '_' + x, field[y][x].type)
  }
}

function RemoveButton (removetype) {
  if (remove === 0) {
    remove = removetype
    addsub = 'sub'
    if (removetype === 1) {
      document.getElementById('remove1text').innerHTML = '1'
    } else if (removetype === 2) {
      document.getElementById('removealltext').innerHTML = 'X'
    }
  } else {
    if (remove === 1) {
      if (removetype === 2) {
        addsub = 'sub'
        remove = 2
        document.getElementById('remove1text').innerHTML = ''
        document.getElementById('removealltext').innerHTML = 'X'
      } else if (removetype === 1) {
        addsub = 'add'
        remove = 0
        document.getElementById('remove1text').innerHTML = ''
        document.getElementById('removealltext').innerHTML = ''
      }
    } else {
      if (removetype === 2) {
        addsub = 'add'
        remove = 0
        document.getElementById('remove1text').innerHTML = ''
        document.getElementById('removealltext').innerHTML = ''
      } else if (removetype === 1) {
        addsub = 'sub'
        remove = 1
        document.getElementById('remove1text').innerHTML = '1'
        document.getElementById('removealltext').innerHTML = ''
      }
    }
  }
}

function Remove(slot, amount){
  if(inventory[slot].current >= amount){
    if(inventory[slot].current === amount){
      inventory[slot] = Object.create(empty)
    }else{
      inventory[slot].current -= amount
    }
    RenderInventory(slot)
  }
}

function Craft(item){
  var done = 0
  var remover = []
  var checker = 0
  var recipe = Object.create(item.recipe)
  for(i = 0; i < recipe.length; i+=2){
    for(j = 9; j >= 0; j--){
      if(inventory[j].type === recipe[i]){
        if(inventory[j].current >= recipe[i+1]){
          done += 2
          remover.push(recipe[i+1])
          remover.push(j)
          j = -1
        }
      }
    }
  }
  if(done === recipe.length){
    for(i = 1; i < 10; i++){
      if(inventory[i].type !== 'N'){
        checker += 1
      }
    }
    if(checker !== 9){
      for(i = 0; i < recipe.length; i+=2){
        Remove(remover[i+1], remover[i])
      }
      UpdateInventory(item, item.amount)
    }
  }
}

function Use(){
  if(inventory[0].type !== 'N'){
    if(inventory[0].use === 'place'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'grasstile'){
        field[newY][newX] = Object.create(inventory[0].effect)
        UpdateImage('image_' + newY + '_' + newX, field[newY][newX].type)
        Remove(0, 1)
      }
    }else if(inventory[0].use === 'fill'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'water'){
        inventory[0] = Object.create(inventory[0].effect)
        RenderInventory(0)
      }
    }else if(inventory[0].use === 'water'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'grasstile'){
        inventory[0] = Object.create(bowl)
        RenderInventory(0)
        field[newY][newX] = Object.create(wateredgrass)
        UpdateImage('image_' + newY + '_' + newX, field[newY][newX].type)
        setTimeout(function(){Grow(newY, newX)}, 60000)
      }else if(field[newY][newX].type === 'treesprouttile'){
        inventory[0] = Object.create(bowl)
        RenderInventory(0)
        setTimeout(function(){Grow(newY, newX)}, 120000)
      }
    }else if(inventory[0].use === 'harvest'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'tree'){
        var oldamount = field[newY][newX].amount
        field[newY][newX].amount = 1
        var amount = CheckGatherAmount(newY, newX)
        field[newY][newX].gathered += amount
        field[newY][newX].amount = oldamount
        UpdateInventory(treesprout, amount)
      }
    }else if(inventory[0].use === 'chop'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'emptytree'){
        field[newY][newX] = Object.create(tree)
        UpdateImage('image_' + newY + '_' + newX, field[newY][newX].type)
      }
    }else if(inventory[0].use === 'fire'){
      var newY = pos[0] + verticalmovement[(directions.indexOf(direction))]
      var newX = pos[1] + horizontalmovement[(directions.indexOf(direction))]
      if(field[newY][newX].type === 'firepittile'){
        field[newY][newX] = Object.create(firepittileon)
        UpdateImage('image_' + newY + '_' + newX, field[newY][newX].type)
        setTimeout(function(){
          field[newY][newX] = Object.create(firepittileburned)
          UpdateImage('image_' + newY + '_' + newX, field[newY][newX].type)
        }, 300000)
      }
    }
  }
}

RenderCrafting()

function RenderCrafting(){
  document.getElementById('crafting0').setAttribute('class', 'slot ' + craftingarray[0].type)
  document.getElementById('crafting1').setAttribute('class', 'slot ' + craftingarray[1].type)
  document.getElementById('crafting2').setAttribute('class', 'slot ' + craftingarray[2].type)
}

function Scroll(way){
  var length = craftinglist.length - 3;
  if(way === -1 && craftingscroll > 0){
    craftingscroll--
    craftingarray.pop()
    craftingarray.unshift(craftinglist[craftingscroll])
    RenderCrafting()
  }else if(way === 1 && craftingscroll < length){
    craftingscroll++
    craftingarray.shift()
    craftingarray.push(craftinglist[craftingscroll+2])
    RenderCrafting()
  }
}

function ChooseCraft(item){
  var itemrecipe = item.recipe
  document.getElementById('recipetext').innerHTML = ''
  for(i = 0; i < itemrecipe.length; i+=2){
    document.getElementById('recipetext').innerHTML += itemrecipe[i] + ": " + itemrecipe[i+1].toString() + '<br>'
  }
  chosencraft = Object.create(item)
}

function CheckCraft(item){
  if(item.type !== 'N'){
    Craft(item)
  }
}

function Grow(y, x){
  field[y][x] = Object.create(field[y][x].stage)
  UpdateImage('image_' + y + '_' + x, field[y][x].type)
}

// Declare events
document.getElementById('slot1').addEventListener('click', function(){Slot(1, addsub)})
document.getElementById('slot2').addEventListener('click', function(){Slot(2, addsub)})
document.getElementById('slot3').addEventListener('click', function(){Slot(3, addsub)})
document.getElementById('slot4').addEventListener('click', function(){Slot(4, addsub)})
document.getElementById('slot5').addEventListener('click', function(){Slot(5, addsub)})
document.getElementById('slot6').addEventListener('click', function(){Slot(6, addsub)})
document.getElementById('slot7').addEventListener('click', function(){Slot(7, addsub)})
document.getElementById('slot8').addEventListener('click', function(){Slot(8, addsub)})
document.getElementById('slot9').addEventListener('click', function(){Slot(9, addsub)})
document.getElementById('slot0').addEventListener('click', function(){Slot(0, addsub)})
document.getElementById('remove1').addEventListener('click', function(){RemoveButton(1)})
document.getElementById('removeall').addEventListener('click', function(){RemoveButton(2)})
document.getElementById('workbench').addEventListener('click', function(){Craft(workbench)})
document.getElementById('crafting0').addEventListener('click', function(){ChooseCraft(craftingarray[0])})
document.getElementById('crafting1').addEventListener('click', function(){ChooseCraft(craftingarray[1])})
document.getElementById('crafting2').addEventListener('click', function(){ChooseCraft(craftingarray[2])})
document.getElementById('craftingbutton').addEventListener('click', function(){CheckCraft(chosencraft)})
document.getElementById('chestslot0').addEventListener('click', function(){ChestSlot(0, addsub)})
document.getElementById('chestslot1').addEventListener('click', function(){ChestSlot(1, addsub)})
document.getElementById('chestslot2').addEventListener('click', function(){ChestSlot(2, addsub)})
document.getElementById('chestslot3').addEventListener('click', function(){ChestSlot(3, addsub)})
document.getElementById('chestslot4').addEventListener('click', function(){ChestSlot(4, addsub)})
document.getElementById('chestslot5').addEventListener('click', function(){ChestSlot(5, addsub)})
document.getElementById('chestslot6').addEventListener('click', function(){ChestSlot(6, addsub)})
document.getElementById('chestslot7').addEventListener('click', function(){ChestSlot(7, addsub)})
document.getElementById('chestslot8').addEventListener('click', function(){ChestSlot(8, addsub)})

/*

TO DO LIST:

For 2.0:
-Clean up

For later:
-Add health
-Add food
-Add structures
-Add the ability to mine underground
-Add the farming of crops
-Add tool durability

*/