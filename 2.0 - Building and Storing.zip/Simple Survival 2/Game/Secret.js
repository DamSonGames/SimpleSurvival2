var listener = new window.keypress.Listener()
var secret = 0;

listener.sequence_combo("e y b 0 s s", function() {
   	SecretFunction()
}, true)

function SecretFunction(){
	if(secret == 0){
		secret = 1
		var sheet = document.createElement('link')
		sheet.setAttribute('rel', 'stylesheet')
		sheet.setAttribute('type', 'text/css')
		sheet.setAttribute('href', 'Meta.css')
		document.head.appendChild(sheet);
		directions.pop()
		directions.pop()
		directions.pop()
		directions.pop()
		directions = ['secretleft', 'secretback', 'secretright', 'secretfront']
		UpdatePlayer();
	}else if(secret == 1){
		secret = 0
		directions.pop()
		directions.pop()
		directions.pop()
		directions.pop()
		directions = ['left', 'back', 'right', 'front']
		UpdatePlayer();
	}
}